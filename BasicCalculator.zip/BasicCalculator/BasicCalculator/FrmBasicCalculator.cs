﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BasicCalculator
{
    public partial class FrmBasicCalculator : Form
    {
        public FrmBasicCalculator()
        {
            InitializeComponent();
        }

        private void btnCompute_Click(object sender, EventArgs e)
        {
            float NumA = 0, NumB = 0, Value = 0;
            string setA, setB,  operation, returnVal;

            BasicComputation compute = new BasicComputation();

            setA = tb1.Text;
            setB = tb2.Text;
            NumA = float.Parse(setA);
            NumB = float.Parse(setB);
            operation = cb1.Text;


            if (cb1.SelectedItem.Equals("+"))
            {
                tbOperator.Clear();
                Value = BasicComputation.Addition(NumA, NumB);
                returnVal = Value.ToString();

                tbOperator.AppendText("TOTAL:");
                tbOperator.AppendText(Environment.NewLine);
                tbOperator.AppendText(returnVal);
            }
            else if (cb1.SelectedItem.Equals("-"))
            {
                tbOperator.Clear();
                Value = BasicComputation.Subtraction(NumA, NumB);
                returnVal = Value.ToString();
                tbOperator.AppendText("TOTAL:");
                tbOperator.AppendText(Environment.NewLine);
                tbOperator.AppendText(returnVal);
            }
            else if (cb1.SelectedItem.Equals("*"))
            {
                tbOperator.Clear();
                Value = BasicComputation.Multiplication(NumA, NumB);
                returnVal = Value.ToString();
                tbOperator.AppendText("TOTAL:");
                tbOperator.AppendText(Environment.NewLine);
                tbOperator.AppendText(returnVal);
            }
            else if (cb1.SelectedItem.Equals("/"))
            {
                tbOperator.Clear();
                Value = BasicComputation.Division(NumA, NumB);
                returnVal = Value.ToString();
                tbOperator.AppendText("TOTAL:");
                tbOperator.AppendText(Environment.NewLine);
                tbOperator.AppendText(returnVal);
            }





        }
    }
}
