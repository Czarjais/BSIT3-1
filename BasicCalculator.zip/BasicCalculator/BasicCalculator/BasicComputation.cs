﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicCalculator
{
    internal class BasicComputation
    {
        static float a, b;

        public static float Addition(float num1, float num2)
        {
            a = num1;
            b = num2;
            float adds = a + b;
            return adds;

        }

        public static float Subtraction(float num1, float num2)
        {
            a = num1;
            b = num2;
            float sub = a - b;
            return sub;

        }

        public static float Multiplication(float num1, float num2)
        {
            a = num1;
            b = num2;
            float multi = a * b;
            return multi;

        }


        public static float Division(float num1, float num2)
        {
            a = num1;
            b = num2;
            float div = a / b;
            return div;

        }





    }
}
