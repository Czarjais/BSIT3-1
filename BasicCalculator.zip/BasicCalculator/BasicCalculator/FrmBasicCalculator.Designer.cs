﻿namespace BasicCalculator
{
    partial class FrmBasicCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnCompute = new System.Windows.Forms.Button();
            this.tb1 = new System.Windows.Forms.TextBox();
            this.tb2 = new System.Windows.Forms.TextBox();
            this.cb1 = new System.Windows.Forms.ComboBox();
            this.tbOperator = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(58, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Basic Calculator";
            // 
            // btnCompute
            // 
            this.btnCompute.Location = new System.Drawing.Point(86, 379);
            this.btnCompute.Name = "btnCompute";
            this.btnCompute.Size = new System.Drawing.Size(150, 46);
            this.btnCompute.TabIndex = 1;
            this.btnCompute.Text = "Compute";
            this.btnCompute.UseVisualStyleBackColor = true;
            this.btnCompute.Click += new System.EventHandler(this.btnCompute_Click);
            // 
            // tb1
            // 
            this.tb1.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tb1.Location = new System.Drawing.Point(58, 106);
            this.tb1.Multiline = true;
            this.tb1.Name = "tb1";
            this.tb1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tb1.Size = new System.Drawing.Size(195, 38);
            this.tb1.TabIndex = 2;
            this.tb1.Text = "0";
            this.tb1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb2
            // 
            this.tb2.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tb2.Location = new System.Drawing.Point(58, 224);
            this.tb2.Multiline = true;
            this.tb2.Name = "tb2";
            this.tb2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tb2.Size = new System.Drawing.Size(195, 38);
            this.tb2.TabIndex = 3;
            this.tb2.Text = "0";
            this.tb2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // cb1
            // 
            this.cb1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cb1.FormattingEnabled = true;
            this.cb1.Items.AddRange(new object[] {
            "+",
            "*",
            "-",
            "/"});
            this.cb1.Location = new System.Drawing.Point(130, 175);
            this.cb1.Name = "cb1";
            this.cb1.Size = new System.Drawing.Size(56, 33);
            this.cb1.TabIndex = 4;
            // 
            // tbOperator
            // 
            this.tbOperator.BackColor = System.Drawing.SystemColors.MenuText;
            this.tbOperator.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbOperator.ForeColor = System.Drawing.Color.Yellow;
            this.tbOperator.Location = new System.Drawing.Point(58, 287);
            this.tbOperator.Multiline = true;
            this.tbOperator.Name = "tbOperator";
            this.tbOperator.Size = new System.Drawing.Size(205, 73);
            this.tbOperator.TabIndex = 5;
            this.tbOperator.Text = "Total:\r\n000000\r\n";
            // 
            // FrmBasicCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(339, 450);
            this.Controls.Add(this.tbOperator);
            this.Controls.Add(this.cb1);
            this.Controls.Add(this.tb2);
            this.Controls.Add(this.tb1);
            this.Controls.Add(this.btnCompute);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "FrmBasicCalculator";
            this.Text = "FrmBasicCalculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Button btnCompute;
        private TextBox tb1;
        private TextBox tb2;
        private ComboBox cb1;
        private TextBox tbOperator;
    }
}