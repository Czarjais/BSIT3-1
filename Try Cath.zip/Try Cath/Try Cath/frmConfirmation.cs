﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Try_Cath
{
    public partial class frmConfirmation : Form
    {
        public frmConfirmation()
        {
            InitializeComponent();
        }

        private void frmConfirmation_Load(object sender, EventArgs e)
        {
            lblStudentNo.Text = StudentInformationClass.SetStudentNo.ToString();
            lblAge.Text = StudentInformationClass.SetAge.ToString();
            lblBirthday.Text = StudentInformationClass.SetBirthday.ToString();
            lblContactNo.Text = StudentInformationClass.SetContactNo.ToString();
            lblGender.Text = StudentInformationClass.SetGender;
            lblProgram.Text = StudentInformationClass.SetProgram.ToString();
            lblName.Text = StudentInformationClass.SetProgram.ToString();

        }
    }
}
