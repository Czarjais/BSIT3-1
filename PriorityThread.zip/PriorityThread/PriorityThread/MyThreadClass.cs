﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriorityThread
{
    internal class MyThreadClass
    {
        public static void Thread1()
        {
            for (int LoopCounts = 0; LoopCounts <= 2; LoopCounts++)
            {
                Thread thread = Thread.CurrentThread;
                Console.WriteLine("Name of Thread: " + thread.Name + " = " + LoopCounts);
                Thread.Sleep(500);
            }
        }

        public static void Thread2()
        {
            for (int LoopCounts = 0; LoopCounts <= 5; LoopCounts++)
            {
                Thread thread = Thread.CurrentThread;

                Console.WriteLine("Name of Thread: " + thread.Name + " = " + LoopCounts);

                Thread.Sleep(1500);

            }
        }
    }
}