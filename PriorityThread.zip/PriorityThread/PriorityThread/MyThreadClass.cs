﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriorityThread
{
    internal class MyThreadClass
    {
        public static void Thread1()
        {
            Thread mainthreads = Thread.CurrentThread;
            for (int i = 0; i <= 5; i++)
            {
                Console.WriteLine("Name of thread: " + mainthreads.Name + " = " + i.ToString());
                Thread.Sleep(1500);
            }
        }
    }
   }
