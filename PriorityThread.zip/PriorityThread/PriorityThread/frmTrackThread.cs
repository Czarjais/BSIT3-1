﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PriorityThread
{
    public partial class frmTrackThread : Form
    {
        public frmTrackThread()
        {
            InitializeComponent();
        }
 
        private void button1_Click(object sender, EventArgs e)
        {
            ThreadStart thr = new ThreadStart(MyThreadClass.Thread1);
            Console.WriteLine("- Before Starting Thread-");

            Thread ThreadA = new Thread(thr);
            Thread ThreadB = new Thread(thr);
            ThreadA.Name = "Thread A Process";
            ThreadB.Name = "Thread A Process";

            ThreadA.Start();
            ThreadB.Start();

            ThreadB.Join();
            Console.WriteLine("- End Thread-");
            label1.Text = "- End of Threads - ";
        }

        private void frmTrackThread_Load(object sender, EventArgs e)
        {
            label1.Text = "- Before Starting Thread -";
        }
    }
}
