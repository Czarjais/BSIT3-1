﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PriorityThread
{
    public partial class frmTrackThread : Form
    {
        public frmTrackThread()
        {
            InitializeComponent();
        }
        public void Method()
        {

            Thread threadA = new Thread(new ThreadStart(MyThreadClass.Thread1));
            Thread threadB = new Thread(new ThreadStart(MyThreadClass.Thread2));
            Thread threadC = new Thread(new ThreadStart(MyThreadClass.Thread2));
            Thread threadD = new Thread(new ThreadStart(MyThreadClass.Thread2));


            threadA.Priority = System.Threading.ThreadPriority.Highest;
            threadA.Name = "Thread A Process";
            threadB.Priority = System.Threading.ThreadPriority.Normal;
            threadB.Name = "Thread B Process";

            threadC.Priority = System.Threading.ThreadPriority.AboveNormal;
            threadC.Name = "Thread C Process";
            threadD.Priority = System.Threading.ThreadPriority.BelowNormal;
            threadD.Name = "Thread D Process";

            //places the thread in started state.
            threadA.Start();
            threadB.Start();
            threadC.Start();
            threadD.Start();

            //stop the calling thread until the thread terminates.
            threadA.Join();
            threadB.Join();
            threadC.Join();
            threadD.Join();


        }
        private void button1_Click(object sender, EventArgs e)
        {
            Console.WriteLine();
            Console.WriteLine(" - Thread Started -");
            label1.Text = "-Thread Started - ";
            Console.WriteLine();
            Method();

            Console.WriteLine();
            Console.WriteLine("- Thread Ended -");
            label1.Text = "-Thread Ended _";

        }
    }
}
