﻿using Creating_Text_File;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reading_a_file
{
    public partial class FrmStudentRecord : Form
    {
        public FrmStudentRecord()
        {
            InitializeComponent();
        }

        private void btnFind_Click(object sender, EventArgs e)
        {

            DisplayToList();
       /*     
            try
            {

                openFileDialog1.InitialDirectory = @"C:\";
                openFileDialog1.Title = "Browse Text File";
                openFileDialog1.DefaultExt = "txt";
                openFileDialog1.Filter = "txt files (*.txt) | All Files(*.*) | *.*";
                openFileDialog1.ShowDialog();

                String docPath = openFileDialog1.FileName;
                StreamReader reader = new StreamReader(docPath);
                listView1.Text = reader.ReadToEnd();
                reader.Close();
            }
            catch (System.IO.FileNotFoundException rm)
                {
                
                MessageBox.Show(rm.Message, "File does not found",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
                */
        }
        
        public void DisplayToList()
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.InitialDirectory = @"c:\";
            fileDialog.Title = "Browse Text Files";
            fileDialog.DefaultExt = "txt";
            fileDialog.Filter = "txt files (*.txt) |*.txt | All files (*.*)|*.*";
            fileDialog.ShowDialog();
             string path = fileDialog.FileName;
            using (StreamReader streamReader = File.OpenText(path))
            {
                string _getText = "";
                while ((_getText = streamReader.ReadLine()) != null)
                {
                    Console.WriteLine(_getText);
                    listView1.Items.Add(_getText);
                }
            }

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            FrmRegistration register = new FrmRegistration();
            register.Show();
            this.Hide();
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            MessageBox.Show("Successfully Uploaded!");
                
        }

        private void FrmStudentRecord_Load(object sender, EventArgs e)
        {

        }
    }
}
