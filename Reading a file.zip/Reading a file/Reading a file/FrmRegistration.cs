﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;
using Reading_a_file;

namespace Creating_Text_File
{
    public partial class FrmRegistration : Form
    {
        public FrmRegistration()
        {
            InitializeComponent();
        }

        private void FrmRegistration_Load(object sender, EventArgs e)
        {
            string[] StudentProgram = {
                "BS in Information Technology",
                "BS in Information System",
                "BS in Civil Engineering",
                "BS in Tourism Management"
            };

            foreach (string Program in StudentProgram)
            {  
        Cprogram.Items.Add(Program);
             }
                               string[] StudentGender = 
                                 {                   
                                "Female",
                                "Male"
                                };
                            foreach (string Gender in StudentGender)
                                     Cgender.Items.Add(Gender);
                         }

        private void Bregister_Click(object sender, EventArgs e)
        {
            string StudNo = "Student No. " + Tstudentno.Text;
            string Last = Tlastname.Text;
            string First = Tfirstname.Text;
            string Mid = Tmi.Text;
  
            string full = "Full Name: " + Tlastname.Text + "," + Tfirstname.Text + " " + Tmi.Text + ".";

            string Progam = "Program: " + Cprogram.Text;
            string Gend = "Gender: " + Cgender.Text;
            string Age = "Age: " + Tage.Text;
            string BDay = "Birthday: " + Dbirthdays.Text;
            string Conatct = "Contact No. " + Tcontact.Text;

            string SetFileName = Tstudentno.Text + ". txt";
            string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(docPath, SetFileName)))
            {

                string[] FileOutput = { StudNo, full, Progam, Gend, Age, BDay, Conatct };
                foreach (var fo in FileOutput)
                {
                    outputFile.WriteLine(fo);
                    Console.WriteLine(fo);
                }
                      Close();


            }








        }

        private void btnRecords_Click(object sender, EventArgs e)
        {
            FrmStudentRecord record = new FrmStudentRecord();
            record.Show();
            this.Hide();
        }
    } 
}       

        
    

